<!DOCTYPE html
  PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>

<body
  style="font-family: Calibri light; box-sizing: border-box; background-color: #f5f8fa; color: #2F3133; height: 100%; hyphens: auto; line-height: 1.4; margin: 0; -moz-hyphens: auto; -ms-word-break: break-all; width: 100% !important; -webkit-hyphens: auto; -webkit-text-size-adjust: none; word-break: break-word;">
  <style>
    @media only screen and (max-width: 600px) {
      .inner-body {
        width: 100% !important;
      }

      .footer {
        width: 100% !important;
      }
    }

    @media only screen and (max-width: 500px) {
      .button {
        width: 100% !important;
      }
    }
  </style>
  <table class="wrapper" width="100%" cellpadding="0" cellspacing="0"
    style="font-family: Calibri light; box-sizing: border-box; background-color: #f5f8fa; margin: 0; padding: 0; width: 100%; -premailer-cellpadding: 0; -premailer-cellspacing: 0; -premailer-width: 100%;">
    <tr>
      <td align="center" style="font-family: Calibri light; box-sizing: border-box;">
        <table class="content" width="100%" cellpadding="0" cellspacing="0"
          style="font-family: Calibri light; box-sizing: border-box; margin: 0; padding: 0; width: 100%; -premailer-cellpadding: 0; -premailer-cellspacing: 0; -premailer-width: 100%;">
          <tr>
            <td class="header"
              style="font-family: Calibri light; box-sizing: border-box; padding: 25px 0; text-align: center;">
              <h1
                style="font-family: Calibri light; box-sizing: border-box; color: #2F3133; font-size: 19px; font-weight: bold; text-decoration: none; text-shadow: 0 1px 0 #ffffff;">
                Munich Re Leader Check-In: Your Login Token 
              </h1>
            </td>
          </tr>
          <!-- Email Body -->
          <tr>
            <td class="body" width="100%" cellpadding="0" cellspacing="0"
              style="font-family: Calibri light; box-sizing: border-box; background-color: #ffffff; border-bottom: 1px solid #edeff2; border-top: 1px solid #edeff2; margin: 0; padding: 0; width: 100%; -premailer-cellpadding: 0; -premailer-cellspacing: 0; -premailer-width: 100%;">
              <table class="inner-body" align="center" width="570" cellpadding="0" cellspacing="0"
                style="font-family: Calibri light; box-sizing: border-box; background-color: #ffffff; margin: 0 auto; padding: 0; width: 570px; -premailer-cellpadding: 0; -premailer-cellspacing: 0; -premailer-width: 570px;">
                <!-- Body content -->
                <tr>
                  <td class="content-cell"
                    style="font-family: Calibri light; box-sizing: border-box; padding-top: 35px; padding-bottom: 35px;">
                    <h1
                      style="font-family: Calibri light; box-sizing: border-box; color: #2F3133; font-size: 19px; font-weight: bold; margin-top: 0; text-align: left;">
                      Dear {{ $data->feedbackReceiver }},
                    </h1>
                    <p
                      style="font-family: Calibri light; box-sizing: border-box; color: #2F3133; font-size: 16px; line-height: 1.5em; margin-top: 0; text-align: left;">
                      To log in to the portal, please enter the following login token:</p>
                    <table class="action" align="center" width="100%" cellpadding="0" cellspacing="0"
                      style="font-family: Calibri light; box-sizing: border-box; margin: 30px auto; padding: 0; text-align: center; width: 100%; -premailer-cellpadding: 0; -premailer-cellspacing: 0; -premailer-width: 100%;">
                      <tr>
                        <td align="center" style="font-family: Calibri light; box-sizing: border-box;">
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"
                            style="font-family: Calibri light; box-sizing: border-box;">
                            <tr>
                              <td align="center"
                                style="font-family: Calibri light; box-sizing: border-box;"> 
                                <table border="0" cellpadding="0" cellspacing="0"
                                  style="font-family: Calibri light; box-sizing: border-box;">
                                  <tr>
                                    <td style="font-family: Calibri light; box-sizing: border-box;background-color: #f5f8fa;padding: 10px"><strong>{{ $data->token }}</strong></td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                          </table>
                        </td>
                      </tr>
                    </table>
                    <br>
                    <p
                      style="font-family: Calibri light; box-sizing: border-box; color: #2F3133; font-size: 16px; line-height: 1.5em; margin-top: 0; text-align: left;">
                      If you have any further questions, please contact <a href="mailto:p0060009039@munichre.com" style="color: #2F3133; text-decoration: none;">Leader CheckIn-(Pool)</a>.
                    </p>
                    <p
                      style="font-family: Calibri light; box-sizing: border-box; color: #2F3133; font-size: 16px; line-height: 1.5em; margin-top: 0; text-align: left;">
                      Best regards,<br>
                      Vocatus</p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td style="font-family: Calibri light; box-sizing: border-box; background-color: #f5f8fa">
              <table class="footer" align="center" width="570" cellpadding="0" cellspacing="0"
                style="font-family: Calibri light; box-sizing: border-box; margin: 0 auto; padding: 0; text-align: center; width: 570px; -premailer-cellpadding: 0; -premailer-cellspacing: 0; -premailer-width: 570px;">
                <tr>
                  <td class="content-cell" align="center"
                    style="font-family: Calibri light; box-sizing: border-box; padding-top: 10px; padding-bottom: 10px">
                    <p
                      style="font-family: Calibri light; box-sizing: border-box; line-height: 1.5em; margin-top: 0; color: #2F3133; font-size: 12px; text-align: left;">
                      Vocatus WorkPerfect GmbH fait partie de Accenture GmbH depuis le 01/05/2024. Vous recevez cet e-mail parce que Münchener Rückversicherungs-Gesellschaft AG et {{ $data->feedbackReceiver }} ({{ $data->feedbackReceiverMail }}) ont engagé Vocatus WorkPerfect GmbH pour conduire le Manager Check-In. Dans ce contexte, des données personnelles ont été communiquées pour une utilisation unique. Pour plus d’informations, veuillez cliquer sur «Protection des données», ci-dessous.</p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td style="padding: 20px 20px 20px 20px; background-color: #28ADE4">
              <table border="0" cellpadding="0" cellspacing="0" width="100%">
                <tbody>
                  <tr>
                    <td align="center" style="font-family: sans-serif; font-size: 14px; color: #ffffff;"><a
                        href="{{ url(config('vocatus.dataprotection_url')) }}"
                        style="color: #ffffff; text-decoration: none;">Protection des données</a>&nbsp;&middot;&nbsp;<a
                        href="https://www.accenture.com/de-de/support/company-impressum"
                        style="color: #ffffff; text-decoration: none;">Mentions légales</a></td>
                  </tr>
                  <tr>
                    <td align="center"
                      style="font-family: sans-serif; font-size: 10px;color: #ffffff; background-color: #28ADE4; padding-top: 20px;">Accenture GmbH
					  &middot;&nbsp;Registered Office: Kronberg&nbsp;&middot;&nbsp;Register court: Königstein im Taunus, HRB 5920<br />
                      Management Board: Christina Raab (Chairwoman of the Management Board), Tobias Gehlhaar, Sven Gudehus, Markus Heyen, <br />
					  Antje Hoffmann, Corinna Krezer, Marco Lechner, Michael Nolte, Karl Rathgeb, Tobias Regenfuß, Patrick Vollmer u.a.
					  </td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>

</html>